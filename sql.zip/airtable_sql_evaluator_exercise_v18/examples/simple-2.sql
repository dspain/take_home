SELECT
    a1.name AS a1_name,
    a1.age,
    a2.name AS a2_name,
    b.distance
FROM
    a AS a1,
    a AS a2,
    b
